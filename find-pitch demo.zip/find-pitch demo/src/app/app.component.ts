import { Component, ViewChild, ElementRef, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ViewEncapsulation } from '@angular/core';
import { NgForm } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { HttpService } from './http.service';
import * as moment from 'moment';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class AppComponent implements OnInit {
  @Input() searchResult: Object;
  @Input() formattedStartDate: String;
  title = 'Find a Pitch!';
  minDate = new Date(2018, 0, 9);
  maxDate = new Date(2018, 0, 15);

  @ViewChild('pitchSearchForm') pitchSearchForm: ElementRef;

  constructor(public datepipe: DatePipe, private http: HttpService) {}

  ngOnInit() {}

  onSubmit(form: NgForm) {
    const formData = {
      'id' : form.value.pitchId,
      'startDate' : this.datepipe.transform(form.value.startDate, 'yyyy-MM-dd'),
      'endDate' : this.datepipe.transform(form.value.endDate, 'yyyy-MM-dd')
    };

    this.http.getPitchResult(formData).subscribe(
      (response: Response) => {
        if (response) {
          this.searchResult = response;
        }
      },
      (error) => {
        console.log('Error ' + error);
      }
    );
  }
}
