import { TestBed, inject } from '@angular/core/testing';
import { Http, Response } from '@angular/http';
import { HttpService } from './http.service';
import { AppComponent } from './app.component';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/of';

describe('HttpService', () => {

  let service: HttpService;
  let httpClientSpy: { get: jasmine.Spy };

  beforeEach(() => {
    httpClientSpy = jasmine.createSpyObj('Http', ['get']);
    service = new HttpService(<any> httpClientSpy);
  });


  it('should return expected data (HttpClient called once)', () => {
    const expectedData: any =
      [{'type': 'slots',
        'id': '1',
        'attributes': {
            'starts': '2018-01-10T21:20:00+00:00',
            'ends': '2018-01-10T22:00:00+00:00',
            'price': '12',
            'admin_fee': '0.00',
            'currency': 'GBP',
            'availabilities': 0
        }
      },
      {
        'type': 'slots',
        'id': '2',
        'attributes': {
            'starts': '2018-01-10T21:20:00+00:00',
            'ends': '2018-01-10T22:00:00+00:00',
            'price': '12.053',
            'admin_fee': '0.00',
            'currency': 'GBP',
            'availabilities': 0
        }
      }],
      sentData = {
        'id' : '32990',
        'startDate' : '2018-01-09',
        'endDate' : '2018-01-15'
      };
    const expectedDataFormatted = Observable.of(expectedData);
    httpClientSpy.get.and.returnValue(expectedDataFormatted);

    service.getPitchResult(sentData).subscribe(
      response => expect(response).toEqual(expectedData, 'expected search results')
    );
    expect(httpClientSpy.get.calls.count()).toBe(1, 'one call');
  });
});
