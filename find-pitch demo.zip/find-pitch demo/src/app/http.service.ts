import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

import * as moment from 'moment';

@Injectable()
export class HttpService {
  private baseUrl = 'https://api-v2.mylp.info/pitches/';

  constructor(private http: HttpClient) { }
  getPitchResult(urlParams) {
    const baseurl = this.baseUrl,
          url = baseurl + urlParams['id'] + '/slots?filter[starts]=' + urlParams['startDate'] + '&filter[ends]=' + urlParams['endDate'];
    return this.http.get(url)
          .catch(
            (error: Response) => {
              return Observable.throw(error);
            }
          );
  }
}
